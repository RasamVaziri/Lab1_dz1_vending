﻿// Вендинговый автомат - консольное приложение
// Product - класс товара (id, название, цена, количество)
// VM - класс автомата (список товаров, деньги, выручка)
// cash - внесённые деньги, total - общая выручка
// items - список товаров, coins - доступные монеты

using System;
using System.Collections.Generic;
using System.Linq;

namespace VendingMachine
{
    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public int Qty { get; set; }

        public Product(int id, string name, decimal price, int qty)
        {
            Id = id;
            Name = name;
            Price = price;
            Qty = qty;
        }
    }

    public class VM
    {
        private List<Product> items;
        private decimal cash;
        private decimal total;
        private int[] coins = { 1, 2, 5, 10 };

        public VM()
        {
            items = new List<Product>();
            cash = 0;
            total = 0;
            Init();
        }

        private void Init()
        {
            items.Add(new Product(1, "Кола", 50m, 10));
            items.Add(new Product(2, "Пепси", 45m, 8));
            items.Add(new Product(3, "Сникерс", 30m, 15));
            items.Add(new Product(4, "Твикс", 35m, 12));
            items.Add(new Product(5, "Вода", 20m, 20));
        }

        public void Show()
        {
            Console.WriteLine("\nТовары:");

            foreach (var x in items)
            {
                Console.WriteLine($"{x.Id} {x.Name} {x.Price}р x{x.Qty}");
            }
        }

        public void Insert()
        {
            Console.Write("Монета (1 2 5 10): ");

            if (int.TryParse(Console.ReadLine(), out int c) && coins.Contains(c))
            {
                cash += c;
                Console.WriteLine($"Внесено {cash}р");
            }
            else
            {
                Console.WriteLine("Ошибка");
            }
        }

        public void Buy()
        {
            if (cash == 0)
            {
                Console.WriteLine("Внесите деньги");
                return;
            }

            Console.Write("Номер: ");

            if (!int.TryParse(Console.ReadLine(), out int n))
            {
                Console.WriteLine("Ошибка");
                return;
            }

            var p = items.FirstOrDefault(x => x.Id == n);

            if (p == null)
            {
                Console.WriteLine("Не найден");
                return;
            }

            if (p.Qty == 0)
            {
                Console.WriteLine("Закончился");
                return;
            }

            if (cash < p.Price)
            {
                Console.WriteLine($"Нужно {p.Price - cash}р");
                return;
            }

            p.Qty--;
            decimal x = cash - p.Price;
            total += p.Price;

            Console.WriteLine($"Выдан {p.Name}");

            if (x > 0)
            {
                Console.WriteLine($"Сдача {x}р");
            }

            cash = 0;
        }

        public void Return()
        {
            if (cash > 0)
            {
                Console.WriteLine($"Возврат {cash}р");
                cash = 0;
            }
            else
            {
                Console.WriteLine("Нет денег");
            }
        }

        public void ShowCash()
        {
            Console.WriteLine($"Внесено {cash}р");
        }

        public void Admin()
        {
            Console.Write("Пароль: ");

            if (Console.ReadLine() != "admin")
            {
                Console.WriteLine("Ошибка");
                return;
            }

            bool r = true;

            while (r)
            {
                Console.WriteLine("\n1 Добавить");
                Console.WriteLine("2 Пополнить");
                Console.WriteLine("3 Удалить");
                Console.WriteLine("4 Забрать");
                Console.WriteLine("5 Выручка");
                Console.WriteLine("0 Выход");
                Console.Write("> ");

                switch (Console.ReadLine())
                {
                    case "1":
                        Add();
                        break;

                    case "2":
                        Refill();
                        break;

                    case "3":
                        Remove();
                        break;

                    case "4":
                        Collect();
                        break;

                    case "5":
                        ShowTotal();
                        break;

                    case "0":
                        r = false;
                        break;

                    default:
                        Console.WriteLine("Ошибка");
                        break;
                }
            }
        }

        private void Add()
        {
            Console.Write("Название ");
            string n = Console.ReadLine();

            Console.Write("Цена ");
            if (!decimal.TryParse(Console.ReadLine(), out decimal p) || p <= 0)
                return;

            Console.Write("Количество ");
            if (!int.TryParse(Console.ReadLine(), out int q) || q < 0)
                return;

            int id = items.Count > 0 ? items.Max(x => x.Id) + 1 : 1;
            items.Add(new Product(id, n, p, q));

            Console.WriteLine("Добавлено");
        }

        private void Refill()
        {
            Show();

            Console.Write("Номер ");
            if (!int.TryParse(Console.ReadLine(), out int id))
                return;

            var p = items.FirstOrDefault(x => x.Id == id);
            if (p == null)
                return;

            Console.Write($"Есть {p.Qty} Добавить ");
            if (!int.TryParse(Console.ReadLine(), out int a) || a < 0)
                return;

            p.Qty += a;
            Console.WriteLine($"Теперь {p.Qty}");
        }

        private void Remove()
        {
            Show();

            Console.Write("Номер ");
            if (!int.TryParse(Console.ReadLine(), out int id))
                return;

            var p = items.FirstOrDefault(x => x.Id == id);
            if (p == null)
                return;

            items.Remove(p);
            Console.WriteLine("Удалено");
        }

        private void Collect()
        {
            if (total > 0)
            {
                Console.WriteLine($"Забрано {total}р");
                total = 0;
            }
            else
            {
                Console.WriteLine("Пусто");
            }
        }

        private void ShowTotal()
        {
            Console.WriteLine($"Выручка {total}р");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            VM v = new VM();
            bool r = true;

            Console.WriteLine("АВТОМАТ\n");

            while (r)
            {
                Console.WriteLine("1 Товары");
                Console.WriteLine("2 Монета");
                Console.WriteLine("3 Купить");
                Console.WriteLine("4 Возврат");
                Console.WriteLine("5 Баланс");
                Console.WriteLine("9 Админ");
                Console.WriteLine("0 Выход");
                Console.Write("> ");

                switch (Console.ReadLine())
                {
                    case "1":
                        v.Show();
                        break;

                    case "2":
                        v.Insert();
                        break;

                    case "3":
                        v.Buy();
                        break;

                    case "4":
                        v.Return();
                        break;

                    case "5":
                        v.ShowCash();
                        break;

                    case "9":
                        v.Admin();
                        break;

                    case "0":
                        r = false;
                        break;

                    default:
                        Console.WriteLine("Ошибка");
                        break;
                }
            }
        }
    }
}